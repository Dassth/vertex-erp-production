import { test, expect, type Page, type BrowserContext, chromium } from '@playwright/test';
import path from 'path';

const BASE = 'http://localhost:5180';
const PASSWORD = 'Vertex2026!';

// ─── Helpers ────────────────────────────────────────────────────────────────

async function signIn(page: Page, accountName: string, password: string) {
  await page.goto(`${BASE}/login`);
  await page.waitForSelector('input[name="account"]');
  // Click the label wrapping the target account radio
  await page.locator('label').filter({ hasText: accountName }).click();
  // Fill password
  const pwInput = page.locator('input[name="password"]');
  await pwInput.fill(password);
  // First-time: fill confirm if visible
  const confirmInput = page.locator('input[name="confirm-password"]');
  if (await confirmInput.isVisible({ timeout: 1500 }).catch(() => false)) {
    await confirmInput.fill(password);
    await page.getByRole('button', { name: 'Create password & sign in' }).click();
  } else {
    await page.getByRole('button', { name: 'Sign in' }).click();
  }
  await page.waitForURL(url => !url.toString().includes('/login'), { timeout: 15000 });
}

async function signOut(page: Page) {
  const accountBtn = page.getByRole('button', { name: /^Account —/ });
  if (await accountBtn.isVisible({ timeout: 3000 }).catch(() => false)) {
    await accountBtn.click();
    await page.getByRole('button', { name: 'Sign out' }).click();
  } else {
    await page.evaluate(() => sessionStorage.clear());
    await page.goto(`${BASE}/login`);
  }
  await page.waitForURL(/\/login/, { timeout: 10000 });
}

async function nav(page: Page, target: string) {
  const routes: Record<string, string> = {
    'Planning': '/planning',
    'Costing': '/costing',
    'Production': '/production',
    'Dispatch': '/dispatch',
    'Billing': '/billing'
  };
  await page.goto(`${BASE}${routes[target]}`);
}

async function navMaster(page: Page, sub: 'Products' | 'Costing' | 'Customers') {
  const routes = {
    'Products': '/master/products',
    'Costing': '/master/costing',
    'Customers': '/master/customers'
  };
  await page.goto(`${BASE}${routes[sub]}`);
}

// ─── Tests ──────────────────────────────────────────────────────────────────

test.describe.serial('Vertex ERP — Full Acceptance', () => {
  let context: BrowserContext;
  let page: Page;

  test.beforeAll(async () => {
    const userDataDir = path.resolve('e2e', '.playwright-profile');
    context = await chromium.launchPersistentContext(userDataDir, {
      headless: true,
      viewport: { width: 1280, height: 800 },
      args: ['--disable-gpu', '--no-sandbox'],
    });
    page = context.pages()[0] ?? await context.newPage();
  });

  test.afterAll(async () => {
    await context?.close();
  });

  // ── Phase 1: Master Setup (Admin 1) ─────────────────────────────────────

  test('1a. Sign in as Administrator 1 and add People', async () => {
    test.setTimeout(90_000);
    await signIn(page, 'Administrator 1', PASSWORD);

    await page.getByRole('button', { name: /^Account —/ }).click();
    await page.getByText('Units, people & machines').click();
    await page.waitForURL(/\/settings/);

    const unitSelect = page.getByLabel('Unit').first();
    await unitSelect.selectOption({ label: 'Unit 1' });
    await page.getByLabel('Name').first().fill('Ravi Kumar');
    await page.getByLabel('Designation').fill('Press operator');
    await page.getByRole('button', { name: 'Add person' }).click();
    await expect(page.getByText('Ravi Kumar').first()).toBeVisible({ timeout: 5000 });

    await unitSelect.selectOption({ label: 'Unit 2' });
    await page.getByLabel('Name').first().fill('Suresh M');
    await page.getByLabel('Designation').fill('Machine operator');
    await page.getByRole('button', { name: 'Add person' }).click();
    await expect(page.getByText('Suresh M').first()).toBeVisible({ timeout: 5000 });
  });

  test('1b. Add machine to Unit 2', async () => {
    test.setTimeout(60_000);
    await page.getByRole('button', { name: /Machines/i }).click();
    await page.waitForURL(/tab=machines/);
    const unitSelect = page.getByLabel('Unit').first();
    await unitSelect.selectOption({ label: 'Unit 2' });
    await page.getByLabel('Machine name').fill('Heidelberg SM 52');
    await page.getByLabel('Code').fill('HSM-52');
    await page.locator('button', { hasText: 'Add machine' }).click();
    await expect(page.getByText('Heidelberg SM 52').first()).toBeVisible({ timeout: 5000 });
  });

  test('1c. Create product with stage and three processes', async () => {
    test.setTimeout(120_000);
    await navMaster(page, 'Products');
    const newLink = page.getByRole('link', { name: 'New product' }).first();
    await newLink.click();
    await page.waitForURL(/\/master\/products\/(new|[a-z0-9-]+)/i);

    await page.getByLabel('Product name').fill('Acceptance Test Box');

    const stageCountInput = page.getByLabel('Number of stages');
    if (await stageCountInput.isVisible({ timeout: 2000 }).catch(() => false)) {
      await stageCountInput.fill('1');
      await page.getByRole('button', { name: /Generate.*stage/ }).click();
    } else {
      await page.getByRole('button', { name: 'Add stage' }).click();
    }

    await page.getByLabel('Stage name').fill('Print & Inspect');

    const addProcessBtn = page.getByRole('button', { name: /Add process to stage/ });
    const processNameFields = page.getByLabel('Process name');
    const existingCount = await processNameFields.count();
    if (existingCount === 0) await addProcessBtn.click();
    await processNameFields.first().fill('Plate preparation');
    await page.getByLabel('Rate ₹').first().fill('100');
    await page.getByLabel('Setup charge ₹').first().fill('0');

    await addProcessBtn.click();
    await processNameFields.nth(1).fill('Offset printing');
    await page.getByLabel('Rate ₹').nth(1).fill('500');
    await page.getByLabel('Setup charge ₹').nth(1).fill('200');
    await page.getByLabel('This process needs a machine').nth(1).check();

    await addProcessBtn.click();
    await processNameFields.nth(2).fill('Print inspection');
    await page.getByLabel('Rate ₹').nth(2).fill('0');
    await page.getByLabel('Setup charge ₹').nth(2).fill('0');

    await page.getByRole('button', { name: 'New material…' }).click();
    await page.getByLabel('Material name').fill('Test Board');
    await page.getByLabel('Quantity material').check();
    await page.getByLabel('Unit of measure').fill('pcs');
    await page.getByLabel(/Price/).fill('15');
    await page.getByRole('button', { name: 'Create & add' }).click();
    await expect(page.getByRole('listitem').filter({ hasText: 'Test Board' }).first()).toBeVisible({ timeout: 5000 });

    await page.getByRole('button', { name: 'Create product' }).click();
    await page.waitForURL(/\/master\/products\/(?!new)[a-z0-9-]+/i, { timeout: 10000 });
    await expect(page.getByRole('heading', { name: 'Acceptance Test Box' })).toBeVisible();
  });

  test('1d. Create customer', async () => {
    test.setTimeout(60_000);
    await navMaster(page, 'Customers');
    await page.locator('button:has-text("customer")').first().click();

    await page.getByLabel('Company name').fill('Apex Industries');
    await page.getByLabel('GSTIN').fill('33AABCU9603R1ZP');
    await page.getByLabel('Billing address').fill('123 Industrial Area\nChennai 600001');
    await page.getByRole('button', { name: 'Create customer' }).click();
    await expect(page.getByText('Apex Industries').first()).toBeVisible({ timeout: 5000 });
  });

  test('1e. Persistence check — reload preserves Master data', async () => {
    await page.reload();
    await page.waitForLoadState('networkidle');
    await expect(page.getByText('Apex Industries').first()).toBeVisible({ timeout: 5000 });
  });

  // ── Phase 2: Planning & Costing ─────────────────────────────────────────

  test('2a. Create plan with cross-unit process allocation', async () => {
    test.setTimeout(120_000);
    await nav(page, 'Planning');
    await page.getByRole('link', { name: 'New plan' }).first().click();
    await page.waitForURL(/\/planning\/(new|[a-z0-9-]+)/i);

    await page.locator('select', { hasText: 'Select a customer' }).selectOption({ index: 1 });
    await page.locator('select', { hasText: 'Select a product' }).selectOption({ index: 1 });
    await page.getByLabel(/Quantity/).fill('1000');

    const today = new Date();
    const orderDate = today.toISOString().split('T')[0];
    const delivery = new Date(today.getTime() + 14 * 86400000).toISOString().split('T')[0];
    await page.getByLabel('Order date').fill(orderDate);
    await page.getByLabel('Required delivery date').fill(delivery);

    await page.getByLabel('Unit for Print & Inspect Plate preparation').selectOption({ label: 'Unit 1' });
    await page.getByLabel('Unit for Print & Inspect Offset printing').selectOption({ label: 'Unit 2' });
    await page.getByLabel('Unit for Print & Inspect Print inspection').selectOption({ label: 'Unit 1' });

    await page.getByRole('button', { name: 'Save & send to costing' }).click();
    await page.waitForURL(/\/costing\//, { timeout: 15000 });
  });

  test('2b. Finalize costing → production order created', async () => {
    test.setTimeout(90_000);
    await page.getByRole('button', { name: 'Finalize & release to production' }).click();
    await page.getByRole('button', { name: 'Finalize and release' }).click();
    await page.waitForURL(/\/production/, { timeout: 15000 });
  });

  test('2c. Persistence check — reload preserves order', async () => {
    await page.reload();
    await page.waitForLoadState('networkidle');
    await expect(page.getByText('Acceptance Test Box').first()).toBeVisible({ timeout: 5000 });
  });

  // ── Phase 3: Unit 1 — First Execution ───────────────────────────────────

  test('3a. Unit 1 Supervisor — assign and complete Plate preparation', async () => {
    test.setTimeout(90_000);
    await signOut(page);
    await signIn(page, 'Unit 1 Supervisor', PASSWORD);
    await expect(page.url()).toContain('/production');

    await page.getByRole('button', { name: /^Ready now/ }).click();
    await page.getByText('Plate preparation').first().click();

    await page.getByRole('button', { name: /Assign person/ }).click();
    const personSelect = page.getByLabel('Responsible person');
    await personSelect.selectOption({ label: 'Ravi Kumar' });
    await page.getByRole('button', { name: 'Save allocation' }).click();

    await page.getByRole('button', { name: 'Start process' }).click();
    await page.getByRole('button', { name: 'Complete process' }).click();
    await page.getByRole('button', { name: 'Complete process' }).click();

    await page.getByRole('button', { name: /^Waiting/ }).click();
    await expect(page.getByText('Print inspection').first()).toBeVisible({ timeout: 5000 });
  });

  test('3b. Persistence check', async () => {
    await page.reload();
    await page.waitForLoadState('networkidle');
    await page.getByRole('button', { name: /^Completed/ }).click();
    await expect(page.getByText('Plate preparation').first()).toBeVisible({ timeout: 5000 });
  });

  // ── Phase 4: Unit 2 — Offset Printing ───────────────────────────────────

  test('4a. Unit 2 Supervisor — complete Offset printing', async () => {
    test.setTimeout(90_000);
    await signOut(page);
    await signIn(page, 'Unit 2 Supervisor', PASSWORD);
    await expect(page.url()).toContain('/production');

    await page.getByRole('button', { name: /^Ready now/ }).click();
    await page.getByText('Offset printing').first().click();

    await page.getByRole('button', { name: /Assign person/ }).click();
    await page.getByLabel('Responsible person').selectOption({ label: 'Suresh M' });
    await page.getByLabel('Machine').selectOption({ label: 'Heidelberg SM 52' });
    await page.getByRole('button', { name: 'Save allocation' }).click();

    await page.getByRole('button', { name: 'Start process' }).click();
    await page.getByRole('button', { name: 'Complete process' }).click();
    await page.getByRole('button', { name: 'Complete process' }).click();
  });

  test('4b. Persistence check', async () => {
    await page.reload();
    await page.waitForLoadState('networkidle');
    await page.getByRole('button', { name: /^Completed/ }).click();
    await expect(page.getByText('Offset printing').first()).toBeVisible({ timeout: 5000 });
  });

  // ── Phase 5: Unit 1 — Print Inspection ──────────────────────────────────

  test('5a. Unit 1 Supervisor — complete Print inspection', async () => {
    test.setTimeout(90_000);
    await signOut(page);
    await signIn(page, 'Unit 1 Supervisor', PASSWORD);

    await page.getByRole('button', { name: /^Ready now/ }).click();
    await page.getByText('Print inspection').first().click();

    await page.getByRole('button', { name: /Assign person/ }).click();
    await page.getByLabel('Responsible person').selectOption({ label: 'Ravi Kumar' });
    await page.getByRole('button', { name: 'Save allocation' }).click();

    await page.getByRole('button', { name: 'Start process' }).click();
    await page.getByRole('button', { name: 'Complete process' }).click();
    await page.getByRole('button', { name: 'Complete process' }).click();
  });

  // ── Phase 6: Dispatch & Invoicing (Admin 1) ─────────────────────────────

  test('6a. Partial dispatch — 100 pieces', async () => {
    test.setTimeout(90_000);
    await signOut(page);
    await signIn(page, 'Administrator 1', PASSWORD);
    await nav(page, 'Dispatch');

    await page.getByRole('button').filter({ hasText: /^JOB-/ }).first().click();
    await page.getByLabel('Dispatch quantity').fill('100');
    await page.getByRole('button', { name: 'Confirm dispatch & issue invoice' }).click();
    await page.getByRole('button', { name: 'Confirm & issue invoice' }).click();
    await expect(page.getByText(/INV-/).first()).toBeVisible({ timeout: 10000 });
  });

  test('6b. Second dispatch — 200 pieces', async () => {
    test.setTimeout(60_000);
    await page.getByLabel('Dispatch quantity').fill('200');
    await page.getByRole('button', { name: 'Confirm dispatch & issue invoice' }).click();
    await page.getByRole('button', { name: 'Confirm & issue invoice' }).click();
    await expect(page.getByText(/INV-/).first()).toBeVisible({ timeout: 10000 });
  });

  test('6c. Verify remaining balance is 700', async () => {
    await expect(page.getByText('700').first()).toBeVisible({ timeout: 5000 });
  });

  test('6d. Reject dispatch of 701', async () => {
    test.setTimeout(30_000);
    await page.getByLabel('Dispatch quantity').fill('701');
    await page.getByRole('button', { name: 'Confirm dispatch & issue invoice' }).click();
    const errorOrDisabled = await page.getByText(/exceeds|cannot|invalid|maximum/i).first().isVisible({ timeout: 3000 }).catch(() => false);
    expect(errorOrDisabled || await page.getByRole('button', { name: 'Confirm dispatch & issue invoice' }).isDisabled()).toBeTruthy();
  });

  test('6e. Persistence check', async () => {
    await page.reload();
    await page.waitForLoadState('networkidle');
    await expect(page.getByText(/INV-/).first()).toBeVisible({ timeout: 5000 });
  });

  // ── Phase 7: Administrator 2 — Operations Access ────────────────────────

  test('7a. Admin 2 can access Production, Dispatch, Billing', async () => {
    test.setTimeout(60_000);
    await signOut(page);
    await signIn(page, 'Administrator 2', PASSWORD);
    const navArea = page.getByRole('navigation', { name: 'Modules' });
    await expect(navArea.getByRole('link', { name: 'Production' })).toBeVisible();
    await expect(navArea.getByRole('link', { name: 'Dispatch' })).toBeVisible();
    await expect(navArea.getByRole('link', { name: 'Billing' })).toBeVisible();
  });

  test('7b. Admin 2 cannot access Master, Planning, Costing, Settings', async () => {
    const navArea = page.getByRole('navigation', { name: 'Modules' });
    await expect(navArea.getByRole('button', { name: 'Master' })).not.toBeVisible();
    await expect(navArea.getByRole('link', { name: 'Planning' })).not.toBeVisible();
    await expect(navArea.getByRole('link', { name: 'Costing' })).not.toBeVisible();

    await page.goto(`${BASE}/master/products`);
    await expect(page.url()).not.toContain('/master/products');
    await page.goto(`${BASE}/planning`);
    await expect(page.url()).not.toContain('/planning');
    await page.goto(`${BASE}/settings`);
    await expect(page.url()).not.toContain('/settings');
  });

  // ── Phase 8: Administrator 3 — Billing Only ─────────────────────────────

  test('8a. Admin 3 can access Billing only', async () => {
    test.setTimeout(60_000);
    await signOut(page);
    await signIn(page, 'Administrator 3', PASSWORD);
    const navArea = page.getByRole('navigation', { name: 'Modules' });
    await expect(navArea.getByRole('link', { name: 'Billing' })).toBeVisible();
  });

  test('8b. Admin 3 cannot access other modules', async () => {
    const navArea = page.getByRole('navigation', { name: 'Modules' });
    await expect(navArea.getByRole('button', { name: 'Master' })).not.toBeVisible();
    await expect(navArea.getByRole('link', { name: 'Planning' })).not.toBeVisible();
    await expect(navArea.getByRole('link', { name: 'Production' })).not.toBeVisible();
    await expect(navArea.getByRole('link', { name: 'Dispatch' })).not.toBeVisible();

    await page.goto(`${BASE}/dispatch`);
    await expect(page.url()).not.toContain('/dispatch');
    await page.goto(`${BASE}/production`);
    await expect(page.url()).not.toContain('/production');
  });

  test('8c. Admin 3 can view invoices in Billing', async () => {
    await nav(page, 'Billing');
    await expect(page.getByText(/INV-/).first()).toBeVisible({ timeout: 5000 });
  });

  // ── Phase 9: New Order (Migrated Process Testing) ───────────────────────

  test('9a. Admin 1 — create second order, partial execution', async () => {
    test.setTimeout(120_000);
    await signOut(page);
    await signIn(page, 'Administrator 1', PASSWORD);

    await nav(page, 'Planning');
    await page.getByRole('link', { name: 'New plan' }).first().click();
    await page.waitForURL(/\/planning\/(new|[a-z0-9-]+)/i);

    await page.locator('select', { hasText: 'Select a customer' }).selectOption({ index: 1 });
    await page.locator('select', { hasText: 'Select a product' }).selectOption({ index: 1 });
    await page.getByLabel(/Quantity/).fill('500');

    const today = new Date();
    await page.getByLabel('Order date').fill(today.toISOString().split('T')[0]);
    await page.getByLabel('Required delivery date').fill(
      new Date(today.getTime() + 21 * 86400000).toISOString().split('T')[0]
    );

    await page.getByLabel('Unit for Print & Inspect Plate preparation').selectOption({ label: 'Unit 1' });
    await page.getByLabel('Unit for Print & Inspect Offset printing').selectOption({ label: 'Unit 2' });
    await page.getByLabel('Unit for Print & Inspect Print inspection').selectOption({ label: 'Unit 1' });

    await page.getByRole('button', { name: 'Save & send to costing' }).click();
    await page.waitForURL(/\/costing\//, { timeout: 15000 });

    await page.getByRole('button', { name: 'Finalize & release to production' }).click();
    await page.getByRole('button', { name: 'Finalize and release' }).click();
    await page.waitForURL(/\/production/, { timeout: 15000 });
  });

  test('9b. Start but do not complete first process on second order', async () => {
    test.setTimeout(60_000);
    await signOut(page);
    await signIn(page, 'Unit 1 Supervisor', PASSWORD);

    await page.getByRole('button', { name: /^Ready now/ }).click();
    await page.getByText('Plate preparation').first().click();

    await page.getByRole('button', { name: /Assign person/ }).click();
    await page.getByLabel('Responsible person').selectOption({ label: 'Ravi Kumar' });
    await page.getByRole('button', { name: 'Save allocation' }).click();

    await page.getByRole('button', { name: 'Start process' }).click();
    await expect(page.getByText(/In progress/i).first()).toBeVisible({ timeout: 5000 });
  });

  test('9c. Final persistence check — all data intact', async () => {
    await page.reload();
    await page.waitForLoadState('networkidle');
    await expect(page.getByText('Plate preparation').first()).toBeVisible({ timeout: 5000 });
    const dbRaw = await page.evaluate(() => localStorage.getItem('vertex-erp-db-v2'));
    expect(dbRaw).toBeTruthy();
    const db = JSON.parse(dbRaw!);
    expect(db.version).toBe(2);
    expect(db.orders.length).toBeGreaterThanOrEqual(2);
    expect(db.dispatches.length).toBeGreaterThanOrEqual(2);
    expect(db.invoices.length).toBeGreaterThanOrEqual(2);
    expect(db.people.length).toBeGreaterThanOrEqual(2);
    expect(db.machines.length).toBeGreaterThanOrEqual(1);
  });
});
