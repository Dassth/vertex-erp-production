
create table if not exists vertex_state (
  id smallint primary key check (id = 1),
  revision bigint not null,
  data jsonb not null,
  updated_at timestamptz not null,
  updated_by text not null
);
create table if not exists vertex_history (
  revision bigint primary key,
  command text not null,
  actor text not null,
  at timestamptz not null default now(),
  data jsonb not null
);
create table if not exists vertex_sessions (
  token_hash text primary key,
  user_id text not null,
  created_at timestamptz not null default now(),
  expires_at timestamptz not null
);
create table if not exists vertex_drafts (
  user_id text not null,
  draft_key text not null,
  rev bigint not null,
  data text not null,
  updated_at timestamptz not null default now(),
  primary key (user_id, draft_key)
);
create table if not exists vertex_meta (
  key text primary key,
  value text not null
);
