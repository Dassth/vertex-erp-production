# Restore Instructions

Run the import UI or `npm run server:restore <file.zip>`