# Restoring a Vertex ERP backup

This archive restores the application data only up to its export time (see
manifest.json → exportedAt and database.revision). Anything saved later is not in it.

1. Prepare an EMPTY PostgreSQL database (a new Supabase project or any PostgreSQL 15+).
2. Fill in config.template.env for the destination and keep it out of source control.
3. Validate without writing anything:
   node dist-server/main.js restore <archive.zip> --into <DATABASE_URL> --dry-run
4. Restore (the schema in migrations/ is applied first):
   node dist-server/main.js restore <archive.zip> --into <DATABASE_URL> --confirm <destination-label>
   - Account passwords: set VERTEX_BACKUP_PASSPHRASE to the passphrase used when the
     archive was made. Without it, add --without-credentials: every account then
     chooses a new password at its first sign-in.
   - A destination that already holds data is refused. To replace it, add --replace;
     a pre-restore archive of the destination is written first.
5. Start the server against the destination (DATABASE_URL), sign in, check the records.
6. Keep the old deployment until the new one is verified.

The app's own login is used (not Supabase Auth); changing a Supabase account email
does not move these accounts — they live in this archive.
