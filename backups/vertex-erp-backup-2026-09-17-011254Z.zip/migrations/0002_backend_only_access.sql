alter table vertex_state enable row level security;
alter table vertex_history enable row level security;
alter table vertex_sessions enable row level security;
alter table vertex_drafts enable row level security;
alter table vertex_meta enable row level security;
do $$
begin
  if exists (select 1 from pg_roles where rolname = 'anon') then
    execute 'revoke all on vertex_state, vertex_history, vertex_sessions, vertex_drafts, vertex_meta from anon';
  end if;
  if exists (select 1 from pg_roles where rolname = 'authenticated') then
    execute 'revoke all on vertex_state, vertex_history, vertex_sessions, vertex_drafts, vertex_meta from authenticated';
  end if;
end $$;
