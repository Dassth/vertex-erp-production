do $mig$
begin
  if exists (select 1 from pg_available_extensions where name = 'pgcrypto') then
    create extension if not exists pgcrypto;
    execute $fn$
      create or replace function vertex_pbkdf2_sha256(pw text, salt_hex text, iters integer)
      returns text
      language plpgsql
      immutable strict
      set search_path = pg_catalog, public, extensions
      as $body$
      declare
        k bytea := convert_to(pw, 'UTF8');
        u bytea;
        a bigint; b bigint; c bigint; d bigint;
      begin
        if iters < 1 or iters > 1000000 then raise exception 'invalid iteration count'; end if;
        u := hmac(decode(salt_hex, 'hex') || decode('00000001', 'hex'), k, 'sha256');
        a := ('x' || encode(substring(u from 1 for 8), 'hex'))::bit(64)::bigint;
        b := ('x' || encode(substring(u from 9 for 8), 'hex'))::bit(64)::bigint;
        c := ('x' || encode(substring(u from 17 for 8), 'hex'))::bit(64)::bigint;
        d := ('x' || encode(substring(u from 25 for 8), 'hex'))::bit(64)::bigint;
        for i in 2..iters loop
          u := hmac(u, k, 'sha256');
          a := a # ('x' || encode(substring(u from 1 for 8), 'hex'))::bit(64)::bigint;
          b := b # ('x' || encode(substring(u from 9 for 8), 'hex'))::bit(64)::bigint;
          c := c # ('x' || encode(substring(u from 17 for 8), 'hex'))::bit(64)::bigint;
          d := d # ('x' || encode(substring(u from 25 for 8), 'hex'))::bit(64)::bigint;
        end loop;
        return lpad(to_hex(a), 16, '0') || lpad(to_hex(b), 16, '0') || lpad(to_hex(c), 16, '0') || lpad(to_hex(d), 16, '0');
      end
      $body$
    $fn$;
    -- Only the backend may call it (never the Supabase Data API roles).
    execute 'revoke all on function vertex_pbkdf2_sha256(text, text, integer) from public';
    if exists (select 1 from pg_roles where rolname = 'anon') then
      execute 'revoke all on function vertex_pbkdf2_sha256(text, text, integer) from anon';
    end if;
    if exists (select 1 from pg_roles where rolname = 'authenticated') then
      execute 'revoke all on function vertex_pbkdf2_sha256(text, text, integer) from authenticated';
    end if;
  end if;
end
$mig$;
